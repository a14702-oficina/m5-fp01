<?php
$pass = $_POST["pass"];
$tamanho = strlen($pass);

if ($tamanho < 5) {
    echo "<span style='color: red;'>Password fraca</span>";
} elseif ($tamanho >= 5 && $tamanho <= 8) {
    echo "<span style='color: orange;'>Password média</span>";
} else {
    echo "<span style='color: green;'>Password forte</span>";
}
?>
