<?php
$idade = $_POST["idade"];

if ($idade < 12) {
    echo "👶 Criança";
} elseif ($idade >= 12 && $idade <= 17) {
    echo "🧒 Adolescente";
} else {
    echo "🧑 Adulto";
}
?>

