<?php
$nome = $_POST["nome"];
echo "Olá, $nome! Seja bem-vindo.";
?>
